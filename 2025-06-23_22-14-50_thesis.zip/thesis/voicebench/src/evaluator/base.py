

class Evaluator:
    def evaluate(self, data):
        raise NotImplementedError
