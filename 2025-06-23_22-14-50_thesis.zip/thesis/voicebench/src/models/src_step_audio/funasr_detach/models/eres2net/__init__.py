from .eres2net import ERes2Net
from .eres2net_aug import ERes2NetAug
